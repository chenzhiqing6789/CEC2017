function h = file_sha256(file)
fid=fopen(file,'rb'); assert(fid>=0,'repro:Read','Cannot read %s',file);
guard=onCleanup(@() fclose(fid));
md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(fid)
    b=fread(fid,1048576,'*uint8');
    md.update(typecast(b,'int8'));
end
h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
