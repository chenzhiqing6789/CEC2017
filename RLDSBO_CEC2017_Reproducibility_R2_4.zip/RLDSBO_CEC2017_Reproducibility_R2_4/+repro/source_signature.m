function files = source_signature(root)
% Hash executable source and benchmark data to make resume fail on changes.
paths=[dir(fullfile(root,'*.m')); dir(fullfile(root,'+repro','*.m')); ...
    dir(fullfile(root,'algorithms','*.m')); dir(fullfile(root,'algorithms','private','*.m')); ...
    dir(fullfile(root,'benchmark','*.mexw64')); dir(fullfile(root,'benchmark','input_data_cec2017','*.txt'))];
files=struct('path',{},'sha256',{});
for i=1:numel(paths)
    full=fullfile(paths(i).folder,paths(i).name);
    files(i).path=strrep(full(numel(root)+2:end),'\','/');
    files(i).sha256=repro.file_sha256(full);
end
[~,idx]=sort({files.path}); files=files(idx);
end
