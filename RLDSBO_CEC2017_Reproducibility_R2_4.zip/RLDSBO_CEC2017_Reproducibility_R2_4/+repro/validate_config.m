function cfg = validate_config(cfg)
defaults = cec2017_config();
assert(isequal(sort(fieldnames(cfg)),sort(fieldnames(defaults))), ...
    'repro:Config','Use cec2017_config and modify its documented fields.');
assert(cfg.schemaVersion==1,'repro:Config','Unsupported config schema.');
assert(cfg.dimension==30 && cfg.lowerBound==-100 && cfg.upperBound==100, ...
    'repro:Config','This package supports CEC2017 D30, bounds [-100,100].');
validateattributes(cfg.population,{'numeric'},{'scalar','integer','>=',30});
assert(mod(cfg.population,10)==0,'repro:Config','N must be a multiple of 10 and at least 30 for the retained subgroup implementations.');
validateattributes(cfg.maxFEs,{'numeric'},{'scalar','integer','>=',cfg.population+20});
validateattributes(cfg.runs,{'numeric'},{'scalar','integer','>=',2,'<=',9999});
validateattributes(cfg.functions,{'numeric'},{'vector','integer','>=',1,'<=',30});
assert(numel(unique(cfg.functions))==numel(cfg.functions),'repro:Config','Duplicate function IDs.');
validateattributes(cfg.baseSeed,{'numeric'},{'scalar','integer','>=',0,'<=',2^32-1-310000});
validateattributes(cfg.tracePoints,{'numeric'},{'scalar','integer','>=',2,'<=',cfg.maxFEs});
assert(iscellstr(cfg.algorithms) && ~isempty(cfg.algorithms),'repro:Config','algorithms must be a nonempty cell array of names.');
assert(numel(unique(cfg.algorithms))==numel(cfg.algorithms),'repro:Config','Duplicate algorithm names.');
assert(all(ismember(cfg.algorithms,defaults.algorithms)),'repro:Config','Unknown algorithm.');
assert(ischar(cfg.outputDir) || (isstring(cfg.outputDir)&&isscalar(cfg.outputDir)),'repro:Config','Invalid outputDir.');
cfg.outputDir=char(cfg.outputDir);
% Resolve output directory before the benchmark setup changes pwd.
cfg.outputDir=char(java.io.File(cfg.outputDir).getCanonicalPath());
cfg.functions=cfg.functions(:)';
cfg.algorithms=cfg.algorithms(:)';
end
