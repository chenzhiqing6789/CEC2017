function write_raw_csv(raw,file)
%WRITE_RAW_CSV Seventeen digits preserve binary64 values on round trip.
fid=fopen(file,'w','n','UTF-8'); assert(fid>=0,'repro:Write','Cannot write %s',file);
guard=onCleanup(@() fclose(fid));
fprintf(fid,'Function,Algorithm,Run,Fitness,Metric,Seed,ActualFEs,MaxFEs,InfeasibleFEs,Seconds,Status\n');
for i=1:height(raw)
    fprintf(fid,'%d,%s,%d,%.17g,%s,%d,%d,%d,%d,%.17g,%s\n', ...
        raw.Function(i),raw.Algorithm(i),raw.Run(i),raw.Fitness(i),raw.Metric(i), ...
        raw.Seed(i),raw.ActualFEs(i),raw.MaxFEs(i),raw.InfeasibleFEs(i),raw.Seconds(i),raw.Status(i));
end
end
