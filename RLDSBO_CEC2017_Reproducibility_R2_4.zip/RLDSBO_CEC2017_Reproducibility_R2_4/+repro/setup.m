function [root, guard] = setup()
%SETUP Isolate source lookup and restore caller path/folder on exit.
root = fileparts(fileparts(mfilename('fullpath')));
oldPath = path; oldDir = pwd;
guard = onCleanup(@() restore(oldPath,oldDir));
addpath(root,fullfile(root,'algorithms'),fullfile(root,'benchmark'),'-begin');
cd(fullfile(root,'benchmark')); % Supplied MEX uses relative input_data_cec2017 paths.
if ~ispc || ~strcmp(computer('arch'),'win64')
    error('repro:Platform','Bundled CEC2017 MEX requires 64-bit Windows MATLAB.');
end
assert(exist('cec17_func','file')==3,'repro:MissingMEX','CEC2017 MEX not found.');
expected = fullfile(root,'benchmark','cec17_func.mexw64');
assert(strcmpi(which('cec17_func'),expected),'repro:ShadowedMEX','Unexpected CEC2017 MEX on path.');
assert(license('test','Statistics_Toolbox'),'repro:Toolbox','Statistics and Machine Learning Toolbox is required.');
clear cec17_func % Reset cached benchmark state after changing folder.
end
function restore(oldPath,oldDir)
cd(oldDir); path(oldPath);
end
