function result = run_one(cfg, algorithm, functionId, runId)
%RUN_ONE Count actual scalar objective calls and retain the best feasible value.
% Source return values are saved separately; they are not used to fabricate x.
seed = cfg.baseSeed + 10000*functionId + runId;
oldRng=rng; rngGuard=onCleanup(@() rng(oldRng));
rng(seed,'twister'); rngBefore=rng;
fe=0; best=Inf; bestX=nan(1,cfg.dimension); infeasible=0;
traceFEs=unique(round(linspace(1,cfg.maxFEs,cfg.tracePoints)));
traceFitness=nan(size(traceFEs)); nextTrace=1;
nativeOutput=[]; nativeCurve=[]; status='completed';
timer=tic;
try
    [nativeOutput,nativeCurve]=feval(algorithm,cfg.population,cfg.maxFEs, ...
        cfg.lowerBound,cfg.upperBound,cfg.dimension,@objective);
catch err
    if strcmp(err.identifier,'repro:BudgetReached')
        status='budget_reached';
    else
        rethrow(err);
    end
end
elapsed=toc(timer);
assert(fe>0 && isfinite(best),'repro:NoResult','No finite feasible objective value.');
if fe<cfg.maxFEs, status='returned_early'; end
nativeLength=numel(nativeCurve);
nativeIndices=unique(round(linspace(1,nativeLength,min(cfg.tracePoints,nativeLength))));
nativeSamples=nativeCurve(nativeIndices);
nativeFinal=NaN; if nativeLength>0, nativeFinal=nativeCurve(end); end
result=struct('functionId',functionId,'algorithm',algorithm,'run',runId,'seed',seed, ...
    'fitness',best,'bestPosition',bestX,'actualFEs',fe,'infeasibleFEs',infeasible, ...
    'maxFEs',cfg.maxFEs,'elapsedSeconds',elapsed,'status',status, ...
    'metric','best_feasible_evaluated','traceFEs',traceFEs(traceFEs<=fe), ...
    'traceFitness',traceFitness(traceFEs<=fe),'nativeOutput',nativeOutput, ...
    'nativeFinalFitness',nativeFinal,'nativeCurveLength',nativeLength, ...
    'nativeSampleIndices',nativeIndices,'nativeSampleFitness',nativeSamples, ...
    'rngBefore',rngBefore,'rngAfter',rng);

    function y=objective(x)
        if fe>=cfg.maxFEs
            error('repro:BudgetReached','Requested function-evaluation budget exhausted.');
        end
        assert(isnumeric(x) && isreal(x) && numel(x)==cfg.dimension && all(isfinite(x(:))), ...
            'repro:Candidate','%s produced a nonfinite, complex or malformed candidate.',algorithm);
        x=double(x(:));
        y=cec17_func(x,functionId);
        assert(isscalar(y)&&isreal(y)&&isfinite(y),'repro:Objective','CEC2017 returned an invalid value.');
        fe=fe+1;
        feasible=all(x>=cfg.lowerBound & x<=cfg.upperBound);
        infeasible=infeasible+~feasible;
        % Preserve the algorithm's boundary behavior and objective, but never
        % report an out-of-domain sample as the constrained benchmark optimum.
        if feasible && y<best, best=y; bestX=x'; end
        if nextTrace<=numel(traceFEs) && fe==traceFEs(nextTrace)
            traceFitness(nextTrace)=best; nextTrace=nextTrace+1;
        end
    end
end
