function [best_pos, Convergence_curve] = RL_HPSDE(N, Max_FEs, lb, ub, dim, fobj)
% RL_HPSDE MATLAB framework port of the MetaBox RL-HPSDE baseline.
% NOT the original paper authors' official MATLAB implementation.
%
% Paper: Tan et al., "Differential evolution with hybrid parameters and
% mutation strategies based on reinforcement learning", Swarm and
% Evolutionary Computation 75 (2022), 101194.
% DOI: https://doi.org/10.1016/j.swevo.2022.101194
% Public reference implementation (BSD-3-Clause, license below):
% https://github.com/MetaEvo/MetaBox/tree/8ddb092d9d4338d2e30792564742343544557a25
%   src/agent/rl_hpsde_agent.py (online train_episode update)
%   src/optimizer/rl_hpsde_optimizer.py
%   src/optimizer/operators/{mutate,crossover,boundary_control}.py
%
% Usage: [x, curve] = RL_HPSDE(N, Max_FEs, lb, ub, dim, fobj)
% fobj accepts ONE 1-by-dim row and returns one finite real scalar (minimize).
% Scalar, row-vector and column-vector bounds are accepted.
% N is the caller's INITIAL population size; linear reduction ends at 4.
% Pass N=[] for the reference population size 18*dim. Using N=30 instead
% is an explicit matched-initial-population experiment, not its default.
% Q is reset to zero for EACH run and updated online, with no pretraining.
% Core: 4 DFDC/DRIE states; softmax action selection; 4 combinations of
% {current-to-rand/1,current-to-best/1} x {Cauchy,Levy} F distributions;
% alpha=0.8, gamma=0.5; success-proportion reward; weighted Lehmer memories.
%
% Framework/numerical adaptations relative to the pinned Python reference:
% - All objective calls, including 201-point landscape probes, count in FEs.
%   Stop at exactly Max_FEs; truncate the last trial batch or landscape walk.
%   No post-budget next-state evaluation; terminal TD target has no bootstrap.
% - curve(k) is the best POPULATION fitness after evaluation k, length Max_FEs.
%   Landscape probes do not enter the DE population or update its best, as
%   in the reference. During probes the population-best curve stays constant.
%   FE-indexed output supports the framework's existing MySampling function.
% - No known-optimum early termination or subtraction; return raw fitness.
% - Memory length max(1,floor(dim/2)); population never drops below 4.
% - Define zero-variance DFDC as 0 and the exact 0.15 threshold as difficult.
%   Stable softmax; repeated reflection handles intervals narrower than 10
%   and fixed coordinates. None of these changes add objective evaluations.
% Random generators differ across MATLAB/Python: not a bitwise reproduction.
% Cite both the paper and MetaBox and disclose these adaptations in reporting.
% No Statistics and Machine Learning Toolbox is needed by this file.

    validateattributes(dim, {'numeric'}, {'scalar','integer','positive','finite'});
    if isempty(N), N = 18 * dim; end
    validateattributes(N, {'numeric'}, {'scalar','integer','>=',4,'finite'});
    validateattributes(Max_FEs, {'numeric'}, {'scalar','integer','>=',N,'finite'});
    if ~isa(fobj, 'function_handle')
        error('RL_HPSDE:Objective', 'fobj must be a function handle.');
    end
    lb = expand_bound(lb, dim);
    ub = expand_bound(ub, dim);
    if any(lb > ub) || any(~isfinite(ub-lb))
        error('RL_HPSDE:Bounds', 'Bounds must have a finite nonnegative width.');
    end

    Nmax = N;
    H = max(1, floor(dim/2));
    MF = 0.5 * ones(H,1);
    MCR = 0.5 * ones(H,1);
    memory_index = 1;
    Q = zeros(4,4);
    alpha = 0.8;
    gamma_q = 0.5;
    FEs = 0;
    population_best = inf;
    best_pos = zeros(1,dim);
    Convergence_curve = inf(1,Max_FEs);
    X = lb + rand(N,dim) .* (ub-lb);
    fitness = zeros(N,1);
    for i = 1:N
        fitness(i) = evaluate_point(X(i,:), true);
    end
    [fitness, order] = sort(fitness);
    X = X(order,:);
    if FEs == Max_FEs, return; end
    state = observe_state();

    while FEs < Max_FEs
        NP = size(X,1);
        probabilities = exp(Q(state,:) - max(Q(state,:)));
        probabilities = probabilities / sum(probabilities);
        action = find(rand < cumsum(probabilities),1,'first');
        if isempty(action), action = 4; end

        % Shared memory index for F and CR, as in MetaBox.
        memory_draw = randi(H,NP,1);
        CR = min(1,max(0,MCR(memory_draw) + 0.1*randn(NP,1)));
        locations = MF(memory_draw);
        if action <= 2
            F = locations + 0.1*tan(pi*(rand(NP,1)-0.5));
        else
            % If Z~N(0,1), location+scale/Z^2 has Levy(location,scale).
            F = locations + 0.1 ./ (randn(NP,1).^2);
        end
        negative = F < 0;
        F(negative) = 2*locations(negative) - F(negative);
        F = min(1,F);

        if mod(action,2) == 1
            r = distinct_indices(NP,3);
            V = X + F .* (X(r(:,1),:) - X + X(r(:,2),:) - X(r(:,3),:));
        else
            r = distinct_indices(NP,2);
            V = X + F .* (best_pos - X + X(r(:,1),:) - X(r(:,2),:));
        end
        V = min(ub,max(lb,V));
        jrand = randi(dim,NP,1);
        mask = rand(NP,dim) < CR;
        mask(sub2ind([NP,dim],(1:NP)',jrand)) = true;
        U = X;
        U(mask) = V(mask);

        count = min(NP,Max_FEs-FEs);
        candidate_fitness = zeros(count,1);
        for i = 1:count
            candidate_fitness(i) = evaluate_point(U(i,:), true);
        end
        improved = candidate_fitness < fitness(1:count);
        ids = find(improved);
        if ~isempty(ids)
            gain = fitness(ids) - candidate_fitness(ids);
            MF(memory_index) = weighted_lehmer(gain,F(ids));
            MCR(memory_index) = weighted_lehmer(gain,CR(ids));
            memory_index = mod(memory_index,H) + 1;
        else
            MF(memory_index) = 0.5;
            MCR(memory_index) = 0.5;
        end
        X(ids,:) = U(ids,:);
        fitness(ids) = candidate_fitness(ids);
        [fitness, order] = sort(fitness);
        X = X(order,:);
        % The reference truncates this positive expression to an integer.
        next_N = max(4,floor(Nmax+(4-Nmax)*FEs/Max_FEs));
        next_N = min(NP,next_N);
        X = X(1:next_N,:);
        fitness = fitness(1:next_N);
        population_best = fitness(1);
        best_pos = X(1,:);
        reward = numel(ids)/count;

        if FEs < Max_FEs
            next_state = observe_state();
        else
            next_state = state;
        end
        if FEs == Max_FEs
            target = reward;
        else
            target = reward + gamma_q*max(Q(next_state,:));
        end
        Q(state,action) = Q(state,action) + alpha*(target-Q(state,action));
        state = next_state;
    end

    function value = evaluate_point(point, enters_population)
        % The only call site for fobj: enforce budget and count probes too.
        if FEs >= Max_FEs
            error('RL_HPSDE:Budget', 'Internal function-evaluation budget exceeded.');
        end
        value = fobj(point);
        if ~(isnumeric(value) && isreal(value) && isscalar(value) && isfinite(value))
            error('RL_HPSDE:Fitness', 'fobj must return a finite real scalar.');
        end
        FEs = FEs + 1;
        if enters_population && value < population_best
            population_best = value;
            best_pos = point;
        end
        Convergence_curve(FEs) = population_best;
    end

    function result = observe_state()
        samples = progressive_walk(lb,ub,min(201,Max_FEs-FEs));
        costs = zeros(size(samples,1),1);
        for j = 1:size(samples,1)
            costs(j) = evaluate_point(samples(j,:),false);
        end
        % A short final probe exhausts the budget and is not used to act.
        if numel(costs) < 3
            result = 1;
        else
            result = 1 + double(dfdc(samples,costs,best_pos)) + 2*double(drie(costs));
        end
    end
end

function bound = expand_bound(bound,dim)
    validateattributes(bound,{'numeric'},{'real','finite','vector','nonempty'});
    if isscalar(bound), bound = repmat(bound,1,dim); end
    if numel(bound) ~= dim
        error('RL_HPSDE:Bounds','Each bound must be scalar or contain dim entries.');
    end
    bound = reshape(bound,1,dim);
end

function r = distinct_indices(NP,cols)
    r = randi(NP,NP,cols);
    for col = 1:cols
        repeated = r(:,col)==(1:NP)';
        if col>1, repeated = repeated | any(r(:,col)==r(:,1:col-1),2); end
        while any(repeated)
            r(repeated,col) = randi(NP,sum(repeated),1);
            repeated = r(:,col)==(1:NP)';
            if col>1, repeated = repeated | any(r(:,col)==r(:,1:col-1),2); end
        end
    end
end

function value = weighted_lehmer(gain,samples)
    weights = gain/sum(gain);
    denominator = sum(weights.*samples);
    if denominator > 1e-6
        value = sum(weights.*samples.^2)/denominator;
    else
        value = 0.5;
    end
end

function samples = progressive_walk(lb,ub,count)
    dim = numel(lb);
    samples = zeros(count,dim);
    if count==0, return; end
    zone = ones(1,dim);
    zone(rand(1,dim)<0.5) = -1;
    samples(1,:) = (ub+lb)/2 + zone.*rand(1,dim).*(ub-lb)/2;
    j = randi(dim);
    if zone(j)==-1, samples(1,j)=lb(j); else, samples(1,j)=ub(j); end
    for k = 2:count
        point = samples(k-1,:) - 10*rand(1,dim).*zone;
        % Multiple reflections extend the reference single-reflection rule
        % to narrow boxes without any rejection loop or out-of-bound probe.
        width = ub-lb;
        fixed = width==0;
        point(fixed) = lb(fixed);
        outside = ~fixed & (point<lb | point>ub);
        for j = find(outside)
            z = (point(j)-lb(j))/width(j);
            folded = mod(z,2);
            point(j) = lb(j)+width(j)*(1-abs(folded-1));
            if mod(floor(z),2)~=0, zone(j)=-zone(j); end
        end
        samples(k,:) = min(ub,max(lb,point));
    end
end

function easy = dfdc(samples,costs,best)
    distances = sqrt(sum((samples(2:end,:)-best).^2,2));
    costs = costs(2:end);
    centered_f = costs-mean(costs);
    centered_d = distances-mean(distances);
    denominator = sqrt(mean(centered_f.^2))*sqrt(mean(centered_d.^2));
    if denominator==0
        correlation = 0;
    else
        correlation = mean(centered_f.*centered_d)/denominator;
        correlation = min(1,max(-1,correlation));
    end
    easy = correlation > 0.15;
end

function easy = drie(costs)
    differences = diff(costs);
    steps = numel(differences);
    e_star = max(abs(differences));
    ruggedness = 0;
    pairs = [-1 0; -1 1; 0 -1; 0 1; 1 -1; 1 0];
    for scale = [0 1/128 1/64 1/32 1/16 1/8 1/4 1/2 1]
        symbols = double(differences>scale*e_star) - double(differences<-scale*e_star);
        probability = zeros(6,1);
        for j = 1:6
            probability(j) = sum(symbols(1:end-1)==pairs(j,1) & symbols(2:end)==pairs(j,2))/steps;
        end
        probability = max(probability,1e-15);
        ruggedness = max(ruggedness,-sum(probability.*log(probability)/log(6)));
    end
    easy = ruggedness >= 0.5;
end

% BSD 3-Clause License
% Copyright (c) 2023, MetaEvolution Lab
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 1. Redistributions of source code must retain the above copyright notice,
%    this list of conditions and the following disclaimer.
% 2. Redistributions in binary form must reproduce the above copyright notice,
%    this list of conditions and the following disclaimer in the documentation
%    and/or other materials provided with the distribution.
% 3. Neither the name of the copyright holder nor the names of its contributors
%    may be used to endorse or promote products derived from this software
%    without specific prior written permission.
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
