%SCA+Dimension learning-based hunting+Terminal replacement mechanism
function [Destination_position,Convergence_curve]=GDTSCA(N,MaxFEs,lb,ub,dim,fobj)
%tic
%Initialize the set of random solutions
X=initialization(N,dim,ub,lb);

Destination_position=zeros(1,dim);
Destination_fitness=inf;

Convergence_curve=[];
Objective_values = zeros(1,size(X,1));
FEs=0;
it=1;
% Calculate the fitness of the first set and find the best one
for i=1:size(X,1)
    FEs = FEs+1;
    Objective_values(1,i)=fobj(X(i,:));
    if i==1
        Destination_position=X(i,:);
        Destination_fitness=Objective_values(1,i);
    elseif Objective_values(1,i)<Destination_fitness
        Destination_position=X(i,:);
        Destination_fitness=Objective_values(1,i);
    end
    allfitness(i)=Objective_values(1,i);
    Convergence_curve(it)=Destination_fitness;
end
neighbor = zeros(N,N);
%Main loop
it=it+1; % start from the second iteration since the first iteration was dedicated to calculating the fitness
while FEs<MaxFEs


    % Eq. (3.4)
    a = 2; 
    r1=a-FEs*((a)/MaxFEs); % r1 decreases linearly from a to 0

    % Update the position of solutions with respect to destination
    for i=1:size(X,1) % in i-th solution
        for j=1:size(X,2) % in j-th dimension
            
            % Update r2, r3, and r4 for Eq. (3.3)
            r2=(2*pi)*rand();
            r3=2*rand;
            r4=rand();
            
            % Eq. (3.3)
            if r4<0.5
                % Eq. (3.1)
                newX(i,j)= X(i,j)+(r1*sin(r2)*abs(r3*Destination_position(j)-X(i,j)));
            else
                % Eq. (3.2)
                newX(i,j)= X(i,j)+(r1*cos(r2)*abs(r3*Destination_position(j)-X(i,j)));
            end

        end
        % Check if solutions go outside the search spaceand bring them back
        Flag4ub=newX(i,:)>ub;
        Flag4lb=newX(i,:)<lb;
        newX(i,:)=(newX(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        
        % Calculate the objective values
        
        New_Objective_values(1,i)=fobj(newX(i,:));
        FEs = FEs+1;
        % Update the destination if there is a better solution
        if New_Objective_values(1,i)<allfitness(i)
            allfitness(i)=New_Objective_values(1,i);
            X(i,:)=newX(i,:);
        end
        if allfitness(i)<Destination_fitness
            Destination_position=X(i,:);
            Destination_fitness=allfitness(i);
        end
    end
    
    %==================Dimension learning-based hunting=====================
    % Calculate the candiadate position Xi-DLH
    radius = pdist2(X, newX, 'euclidean');         % Equation (10)
    dist_Position = squareform(pdist(X));
    r1=randperm(N,N);
    
    for t=1:N
        neighbor(t,:) = (dist_Position(t,:)<=radius(t,t));
        [~,Idx] = find(neighbor(t,:)==1);                   % Equation (11)             
        random_Idx_neighbor = randi(size(Idx,2),1,dim);
        

        for d=1:dim
            X_DLH(t,d) = X(t,d) + rand .*(X(Idx(random_Idx_neighbor(d)),d)- X(r1(t),d));                      % Equation (12)   
        end
        
        Flag4ub=X_DLH(t,:)>ub;
        Flag4lb=X_DLH(t,:)<lb;
        X_DLH(t,:)=(X_DLH(t,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        X_DLH_fit(1,t)=fobj(X_DLH(t,:));
        FEs=FEs+1;
%         X_DLH(t,:) = boundConstraint(X_DLH(t,:), Positions(t,:), lu);
%         Fit_DLH(t) = fobj(X_DLH(t,:));
        if X_DLH_fit(1,t)<allfitness(t)
        %if X_DLH_fit(1,t)<New_Objective_values(1,i) && X_DLH_fit(1,t)<allfitness(t)
            X(t,:)=X_DLH(t,:);
            allfitness(t)=X_DLH_fit(1,t);
            if allfitness(t)<Destination_fitness
                Destination_position=X(t,:);
                Destination_fitness=allfitness(t);
            end
        end

    end
    
    % Terminal replacement mechanism
    [worst_fitness,index]=max(allfitness);
    z=[1:index-1,index+1:N];
    d=randperm(length(z),4);
    Xnew=Destination_position+rand*(X(z(d(2)),:)-X(z(d(1)),:));
    %Xnew=Destination_position+rand*(X(z(d(2)),:)-X(z(d(1)),:))+rand*(X(z(d(3)),:)-X(z(d(4)),:));   %DE/best/2
    
    Flag4ub=Xnew>ub;
    Flag4lb=Xnew<lb;
    Xnew=(Xnew.*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    Xnew_fitness=fobj(Xnew);
    FEs=FEs+1;
    if Xnew_fitness<worst_fitness
        X(index,:)=Xnew;
        allfitness(index)=Xnew_fitness;
    end
    if allfitness(index)<Destination_fitness
        Destination_fitness=allfitness(index);
        Destination_position=X(index,:);
    end


    Convergence_curve(it)=Destination_fitness;
    it=it+1;
    neighbor = zeros(N,N);
end

end



