%**************************************************************************************************
% Developed by Guohua Wu, College of Information Systems and Management, National University of Defense Technology,
% Changsha, China, 410073
% guohuawu@nudt.edu.cn

% Reference: 
% Guohua Wu, et.al, Differential Evolution with Multi-Population Based Ensemble of Mutation Strategies.Information Sciences, 2015, 10.1016/j.ins.2015.09.009.
% Note: The codes are optimized a little, thereby, the overall results may be a little better
% than those published in the paper. 
%**************************************************************************************************
function [overallBestVal, convergence]=MPEDE(N,MaxFEs,lb,ub,D,fobj)
	lb=ones(1,D).*lb;
	ub=ones(1,D).*ub;
	CRm2 = 0.5;
	Fm2 = 0.5;
	CRm3 = 0.5;
	Fm3 = 0.5;            
	FES = 0;
    n = D;
	leastSelectionPro = 0.2;
	arrayGbestChange = [1,1,1];
	arrayGbestChangeRate = [0,0,0];
	genForChange = 20;
	mixPopSize = N;
	MaxGen = ceil(MaxFEs/mixPopSize); % Integer allocation for arbitrary budgets.
	indexBestLN = 1;
	numViaLN = [0,0,0];
	rateViaLN = zeros(MaxGen,3);
	lu=[lb; ub];
	mixPop = repmat(lu(1, :), mixPopSize, 1) + rand(mixPopSize, D) .* (repmat(lu(2, :) - lu(1, :), mixPopSize, 1));
    for i=1:size(mixPop,1)
        mixVal(i,1) = fobj(mixPop(i,:));
        %mixVal(1,i) = fobj(mixPop(i,:));%后面多次报错就可以合理怀疑，是后来的改动使得原本应该是列向量的变量变成了行向量，追根溯源，发现源头在此。仔细检查了下有改动了源代码的地方。
    end
	overallBestVal = min(mixVal);
	
	permutation = randperm(mixPopSize);
	arraySecond = permutation(1:leastSelectionPro*mixPopSize);  % for EPSDE
	arrayFirst = permutation(leastSelectionPro*mixPopSize+1: end); %  for JADE
	
	popold = mixPop(arrayFirst,:) ;
	valParents =mixVal(arrayFirst);
	c = 1/10;
	pj = 0.04;
	CRm = 0.5;
	Fm = 0.5;
	Afactor = 1;
	archive.NP = mixPopSize; % the maximum size of the archive
	archive.pop = zeros(0, D); % the solutions stored in te archive
	archive.funvalues = zeros(0, 1); % the function value of the archived solutions
	
	gen = 0;
	FESj = 0;
	initialPopSize = mixPopSize;
	previousPopSize = mixPopSize;
	consumedFES = [1,1,1];
	while  FES <=MaxFEs
		gen = gen +1;                     
		if mod(gen,genForChange) == 0
			arrayGbestChangeRate(1) = arrayGbestChange(1)/consumedFES(1);
			arrayGbestChangeRate(2) = arrayGbestChange(2)/consumedFES(2);
			arrayGbestChangeRate(3) = arrayGbestChange(3)/consumedFES(3);
			[~,indexBestLN]=max(arrayGbestChangeRate);
			if sum(arrayGbestChangeRate == arrayGbestChangeRate(1)) == 3
				indexBestLN = randi([1,3],1);
			end
			arrayGbestChange = [0.1,0.1,0.1];
			arrayGbestChangeRate =  [0,0,0];
			consumedFES = [1,1,1];
		end
		permutation = randperm(mixPopSize);                   
		if indexBestLN == 1               
			arrayThird= permutation(1:leastSelectionPro*mixPopSize);
			arraySecond = permutation(leastSelectionPro*mixPopSize+1: 2*leastSelectionPro*mixPopSize);
			arrayFirst = permutation(2*leastSelectionPro*mixPopSize+1:end);
			numViaLN(1) = numViaLN(1) + 1;
		elseif indexBestLN == 2
			arrayThird = permutation(1:leastSelectionPro*mixPopSize);
			arrayFirst = permutation(leastSelectionPro*mixPopSize+1: 2*leastSelectionPro*mixPopSize);
			arraySecond  = permutation(2*leastSelectionPro*mixPopSize+1:end);
			numViaLN(2) = numViaLN(2) + 1;
		elseif indexBestLN == 3
			arrayFirst = permutation(1:leastSelectionPro*mixPopSize);
			arraySecond = permutation(leastSelectionPro*mixPopSize+1: 2*leastSelectionPro*mixPopSize);
			arrayThird  = permutation(2*leastSelectionPro*mixPopSize+1:end);
			numViaLN(3) = numViaLN(3) + 1;
		end
		rateViaLN(gen,:) = numViaLN/sum(numViaLN);
		consumedFES = consumedFES + [length(arrayFirst),length(arraySecond),length(arrayThird)];
		if mixPopSize<20
		   arrayFirst =  permutation;    
		   arraySecond = [];
		   arrayThird = [];
		end      
	%             pop = popold; % the old population becomes the current population
	%%  %% ===========================mutation 1=====================================%%%%
	   if ~isempty(arrayFirst)               
			pop1 = mixPop(arrayFirst,:); % the old population becomes the current population
			valParents1 = mixVal(arrayFirst);
			popsize = length(arrayFirst);
			[~,I1]=sort(mixVal, 'ascend');
			[~,I2]=sort(valParents1, 'descend');
			pop1(I2(1),:) = mixPop(I1(1),:);
			valParents1(I2(1)) = mixVal(I1(1));
			prevalParents1 = valParents1;
			
			if FESj > 1 && ~isempty(goodCR) && sum(goodF) > 0 % If goodF and goodCR are empty, pause the update
				CRm = (1 - c) * CRm + c * mean(goodCR);
				Fm = (1 - c) * Fm + c * sum(goodF .^ 2) / sum(goodF); % Lehmer mean
			end
			% Generate CR according to a normal distribution with mean CRm, and std 0.1
			% Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
			[Fj, CRj] = randFCR(popsize, CRm, 0.1, Fm, 0.1);
			r0 = [1 : popsize];
			popAll = [pop1; archive.pop];
			[r1, r2] = gnR1R2(popsize, size(popAll, 1), r0);
			% Find the p-best solutions
			[~, indBest] = sort(valParents1, 'ascend');
			pNP = max(round(pj * popsize), 2); % choose at least two best solutions
			randindex = ceil(rand(1, popsize) * pNP); % select from [1, 2, 3, ..., pNP]
			randindex = max(1, randindex); % to avoid the problem that rand = 0 and thus ceil(rand) = 0
			pbest = pop1(indBest(randindex), :); % randomly choose one of the top 100p% solutions
			% == == == == == == == == == == == == == == == Mutation == == == == == == == == == == == == ==
			vi = pop1 + Fj(:, ones(1, n)) .* (pbest - pop1 + pop1(r1, :) - popAll(r2, :));
			vi = boundConstraint(vi, pop1, lu);
			% == == == == = Crossover == == == == =
			mask = rand(popsize, n) > CRj(:, ones(1, n)); % mask is used to indicate which elements of ui comes from the parent
			rows = (1 : popsize)'; cols = floor(rand(popsize, 1) * n)+1; % choose one position where the element of ui doesn't come from the parent
			jrand = sub2ind([popsize n], rows, cols); mask(jrand) = false;
			ui = vi; ui(mask) = pop1(mask);
			
            valOffspring1 = [];%这里重置了valOffspring1
			for i=1:size(ui,1)
				valOffspring1(i,1)=fobj(ui(i,:));%原来代码是直接替换变量，所以变量长度变化不影响，这里用迭代，变量变短后，上一次迭代留下在尾部的变量不会被清除。
                %valOffspring1(1,i)=fobj(ui(i,:));%同理，有改动的地方就可能会有报错，因为之前的改动忽略了变量的行列向量问题。所以有用到fobj的地方都得修改才不会报错。
			end
			FESj = FESj + popsize;
			FES = FES + popsize;
			% I == 1: the parent is better; I == 2: the offspring is better
            
			[valParents1, I] = min([valParents1, valOffspring1], [], 2);
            %valParents1 = valParents1';%根据代码推测，原来代码的意图应该是从子代和父代中对应选取最小的，选出来的种群替换原父代种群。
			popold1 = pop1;
			archive = updateArchive(archive, popold1(I == 2, :), valParents1(I == 2));
			popold1(I == 2, :) = ui(I == 2, :);
			goodCR = CRj(I == 2);
			goodF = Fj(I == 2);  
			if min(valParents1)< overallBestVal
				overallBestVal = min(valParents1);
			end
			arrayGbestChange(1) = arrayGbestChange(1) + sum(prevalParents1- valParents1);
			if prevalParents1(I2(1)) == valParents1(I2(1))
			   popold1(I2(1),:) =  mixPop(arrayFirst(I2(1)),:);
			   valParents1(I2(1)) = mixVal(arrayFirst(I2(1)));
			end
			mixPop(arrayFirst,:) = popold1;
			mixVal(arrayFirst) = valParents1;
	   end
	%             [valBest indBest] = sort(valParents1, 'ascend');
		
		%% ===========================mutation 2=====================================%%%%
	   if ~isempty(arraySecond)
			pop2 = mixPop(arraySecond,:); % the old population becomes the current population 
			valParents2 = mixVal(arraySecond);
			popsize2 = length(arraySecond);
			[~,I1]=sort(mixVal, 'ascend');
			[~,I2]=sort(valParents2, 'descend');
			pop2(I2(1),:) = mixPop(I1(1),:);
			valParents2(I2(1)) = mixVal(I1(1));          
			prevalParents2 = valParents2;
			
			if gen > 1 && ~isempty(goodCR2) && sum(goodF2) > 0 % If goodF and goodCR are empty, pause the update
				CRm2 = (1 - c) * CRm2 + c * mean(goodCR2);
				Fm2 = (1 - c) * Fm2 + c * sum(goodF2 .^ 2) / sum(goodF2); % Lehmer mean
			end
			% Generate CR according to a normal distribution with mean CRm, and std 0.1
			% Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
			[F2, CR2] = randFCR(popsize2, CRm2, 0.1, Fm2, 0.1);
			rot = (0:1:popsize2-1);
			ind = randperm(2);
			a1  = randperm(popsize2);             % shuffle locations of vectors
			rt = rem(rot+ind(1),popsize2);        % rotate indices by ind(1) positions
			a2  = a1(rt+1);                 % rotate vector locations
			rt = rem(rot+ind(2),popsize2);
			a3  = a2(rt+1);
			pm1 = pop2(a1,:);             % shuffled population 1
			pm2 = pop2(a2,:);             % shuffled population 2
			pm3 = pop2(a3,:);             % shuffled population 3
			vi =pop2 + repmat(rand(popsize2,1),1,D) .* (pm1 - pop2) + F2(:, ones(1, D)) .* (pm2 - pm3);
			vi = boundConstraint(vi, pop2, lu);
			ui = vi;
            
            valOffspring2 = [];%修改理由同上%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			for i=1:size(ui,1)
				valOffspring2(i,1)=fobj(ui(i,:));
                %valOffspring2(1,i)=fobj(ui(i,:));
			end
			FES = FES + popsize2;
			% == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
			% I == 1: the parent is better; I == 2: the offspring is better
			[valParents2, I] = min([valParents2, valOffspring2], [], 2);
			popold2 = pop2;
		%             archive = updateArchive(archive, popold(I == 2, :), valParents2(I == 2));
			popold2(I == 2, :) = ui(I == 2, :);
			goodCR2 = CR2(I == 2);
			goodF2 = F2(I == 2);
			
			arrayGbestChange(2) = arrayGbestChange(2) + sum(prevalParents2- valParents2);
			if prevalParents2(I2(1)) == valParents2(I2(1))
				popold2(I2(1),:) =  mixPop(arraySecond(I2(1)),:);
				valParents2(I2(1)) = mixVal(arraySecond(I2(1)));
			end
			mixPop(arraySecond,:) = popold2;
			mixVal(arraySecond) = valParents2;   
	   end
		
	%             [valBest indBest] = sort(valParents2, 'ascend');
	   %% ===========================mutation 3 =====================================%%%%
	   if ~isempty(arrayThird)
			pop3 = mixPop(arrayThird,:); % the old population becomes the current population 
			valParents3 = mixVal(arrayThird);
			popsize3 = length(arrayThird);
			[~,I1]=sort(mixVal, 'ascend');
			[~,I2]=sort(valParents3, 'descend');
			pop3(I2(1),:) = mixPop(I1(1),:);
			valParents3(I2(1)) = mixVal(I1(1));                    
			prevalParents3 = valParents3;
			if gen > 1 && ~isempty(goodCR3) && sum(goodF3) > 0 % If goodF and goodCR are empty, pause the update
				CRm3 = (1 - c) * CRm3 + c * mean(goodCR3);
				Fm3 = (1 - c) * Fm3 + c * sum(goodF3 .^ 2) / sum(goodF3); % Lehmer mean
			end
			% Generate CR according to a normal distribution with mean CRm, and std 0.1
			% Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
			[F3, CR3] = randFCR(popsize3, CRm3, 0.1, Fm3, 0.1);
			rot = (0:1:popsize3-1);
			ind = randperm(2);
			a1  = randperm(popsize3);             % shuffle locations of vectors
			rt = rem(rot+ind(1),popsize3);        % rotate indices by ind(1) positions
			a2  = a1(rt+1);                 % rotate vector locations
			rt = rem(rot+ind(2),popsize3);
			a3  = a2(rt+1);
			pm1 = pop3(a1,:);             % shuffled population 1
			pm2 = pop3(a2,:);             % shuffled population 2
			pm3 = pop3(a3,:);             % shuffled population 3
			vi =pm1 + F3(:, ones(1, D)) .* (pm2 - pm3); %repmat(rand(popsize3,1),1,D) .* (pm1 - pop3) 
			vi = boundConstraint(vi, pop3, lu);
			
			mask = rand(popsize3, n) > CR3(:, ones(1, n)); % mask is used to indicate which elements of ui comes from the parent
			rows = (1 : popsize3)'; cols = floor(rand(popsize3, 1) * n)+1; % choose one position where the element of ui doesn't come from the parent
			jrand = sub2ind([popsize3 n], rows, cols); mask(jrand) = false;
			ui = vi; ui(mask) = pop3(mask);
			
            valOffspring3=[];%修改理由同上%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			for i=1:size(ui,1)
                valOffspring3(i,1)=fobj(ui(i,:));
				%valOffspring3(1,i)=fobj(ui(i,:));
			end
			FES = FES + popsize3;
			% == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
			% I == 1: the parent is better; I == 2: the offspring is better
			[valParents3, I] = min([valParents3, valOffspring3], [], 2);
			popold3 = pop3;
		%             archive = updateArchive(archive, popold(I == 2, :), valParents2(I == 2));
			popold3(I == 2, :) = ui(I == 2, :);
			goodCR3 = CR3(I == 2);
			goodF3 = F3(I == 2);            
			arrayGbestChange(3) = arrayGbestChange(3) + sum(prevalParents3- valParents3);
			
			if prevalParents3(I2(1)) == valParents3(I2(1))
				popold3(I2(1),:) =  mixPop(arrayThird(I2(1)),:);
				valParents3(I2(1)) = mixVal(arrayThird(I2(1)));
			end                     
			mixPop(arrayThird,:) = popold3;
			mixVal(arrayThird) = valParents3;        
       end
	   convergence(gen) = overallBestVal;
   end
end