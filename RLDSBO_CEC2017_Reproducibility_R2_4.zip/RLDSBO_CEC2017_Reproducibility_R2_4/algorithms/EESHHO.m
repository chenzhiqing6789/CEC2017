% Developed in MATLAB R2014b
% Source codes demo version 1.0
% _____________________________________________________

% Main paper:
% Memetic Harris Hawks Optimization: Developments and perspectives on project scheduling and QoS-aware web service composition
% ChenYang Li, Jun Li, Huiling Chen, Ali Asghar Heidari 
% Expert Systems With Applications , 
% DOI: https://doi.org/10.1016/j.eswa.2020.114529
% _____________________________________________________

%  Author, inventor and programmer: ChenYang Li,
%  Email: lcy.yang@foxmail.com
%  Researchgate: https://www.researchgate.net/profile/Chenyang_Li39/experience

% _____________________________________________________
%  Co-author: Ali Asghar Heidari
%  e-Mail: as_heidari@ut.ac.ir, aliasghar68@gmail.com,
%  e-Mail (Singapore): aliasgha@comp.nus.edu.sg, t0917038@u.nus.edu
%  Researchgate: https://www.researchgate.net/profile/Ali_Asghar_Heidari

% _____________________________________________________

%  Co-authors: Jun Li, Huiling Chen
%  Homepage: https://aliasgharheidari.com/publications/EESHHO.html
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% EESHHO: In this algorithm, Harris' hawks try to catch the rabbit.

% T: maximum iterations, N: populatoin size, CNVG: Convergence curve
% To run EESHHO: [Rabbit_Energy,Rabbit_Location,CNVG]=EESHHO(N,T,lb,ub,dim,fobj)

function [Rabbit_Location,CNVG]=EESHHO(N,T,lb,ub,dim,fobj)

disp('EESHHO is now tackling your problem')
tic

Rabbit_Location=zeros(1,dim); Rabbit_Energy=inf;  % Initializing elite chromosomes E1.
Rabbit_Location2=zeros(1,dim); Rabbit_Energy2=inf;  % Initializing elite chromosomes E2.
Rabbit_Location3=zeros(1,dim); Rabbit_Energy3=inf; % Initializing elite chromosomes E3.

X=initialization(N,dim,ub,lb); %Initialize the locations of Harris' hawks
best_X=X;
CNVG=[];
t=0;
fitness=ones(1,N)*(inf);
FEs=0;


while FEs<T
   for i=1:size(X,1)
        % Check boundries 
        FU=X(i,:)>ub;FL=X(i,:)<lb;X(i,:)=(X(i,:).*(~(FU+FL)))+ub.*FU+lb.*FL;
        % fitness of locations 
        fitness1=fobj(X(i,:));
        FEs=FEs+1;
        if fitness1<fitness(1,i)
            best_X(i,:)=X(i,:);
            fitness(1,i)=fitness1;
        end
        % Elitist selection and Update the location of Rabbit  
        if fitness(1,i)<Rabbit_Energy
            Rabbit_Energy=fitness(1,i);
            Rabbit_Location=X(i,:);
        elseif  fitness(1,i)<Rabbit_Energy2    
                Rabbit_Energy2=fitness(1,i);
                Rabbit_Location2=X(i,:);
        elseif   fitness(1,i)<Rabbit_Energy3   
                Rabbit_Energy2=fitness(1,i);
                Rabbit_Location3=X(i,:);
        end
   end  

 E1=2*(1-(FEs/T)); % factor to show the decreaing energy of rabbit

% Update the location of Harris' hawks
for i=1:size(X,1)
    E0=2*rand()-1; %-1<E0<1
    Escaping_Energy=E1*(E0);  % escaping energy of rabbit 
   if abs(Escaping_Energy)>=1
        %% Exploration:
            % Harris' hawks perch randomly based on 2 strategy of HHO:
           q=rand();
            rand_Hawk_index = floor(N*rand()+1);
            X_rand = X(rand_Hawk_index, :);
            if q<0.5
                % perch based on other family members
                 X(i,:)=(X_rand-(rand*abs(X_rand-2*rand*X(i,:))));       
           elseif q>0.5
                % perch on a random tall tree (random site inside group's home range)
                 X(i,:)=((((Rabbit_Location(1,:)-mean(X)))-(rand*((ub-lb)*rand+lb)))); 
            end     
         
        elseif abs(Escaping_Energy)<1
            %% Exploitation:
            % Attacking the rabbit using 2 strategies of HHO
          r=rand;
           if abs(Escaping_Energy)<0.5 && r>=0.5
                   % Hard besiege
                   X(i,:)=(Rabbit_Location)-Escaping_Energy*abs(Rabbit_Location-X(i,:));
           end
          if abs(Escaping_Energy)>0.5 && r>=0.5   
                    % Soft besiege
                    Jump_strength=2*(1-rand()); % random jump strength of the rabbit 
                    X(i,:)=(Rabbit_Location-X(i,:))-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));
          end
          
          %Elite evolution strategy (including 2 different methods) 
         R=rand;
         sp=abs(Escaping_Energy); %Parameter setting (refer to Eq.(5))
       if R>=0.5 && r<0.5  
           %One: Elite natural evolution (This is described in detail in Section 2.1.1.) 
          for j=1:size(X,2)
             r5=rand;
               if r5<sp %Gene cross-recombination of elite chromosomes (refer to Eq.(1)).
                  r6=rand;
                  if r6<0.5
                      N2(1,j)=Rabbit_Location2(1,j);
                  else
                      N2(1,j)=Rabbit_Location3(1,j); 
                  end
                else
                   N2(1,j)=Rabbit_Location(1,j);
               end
           end
             X(i,:)=N2+(normrnd(0,0.33333,1,dim).*abs(N2-X(i,:))); %Gaussian local mutation(refer to Eq.(2)).   
        end
        if R<0.5 &&r<0.5 
            %Two:Elite random mutation (This is described in detail in Section 2.1.2.)).
            j1=round(1+rand*(dim-1));
            GSnum=randn; 
            LB=ones(1,dim)*lb;
            UB=ones(1,dim)*ub;
            V=((UB+LB)/2);
           for j=1:size(X,2)%Gene cross-recombination (refer to Eq.(4)).
             r5=rand;
              if r5<sp || j==j1
                  distance2Leader=abs(V(1,j)-Rabbit_Location(1,j));
                  X(i,j)=V(1,j)+(GSnum*distance2Leader);    %Randomly mutated chromosome (refer to Eq.(3)).
              else
                  X(i,j)=Rabbit_Location(1,j);
              end     
           end
         end
   end
end
    t=t+1;
    CNVG(t)=Rabbit_Energy;
end
toc
end


