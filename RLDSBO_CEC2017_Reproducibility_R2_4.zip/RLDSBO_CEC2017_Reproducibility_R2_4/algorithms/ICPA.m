function [Target,CV]=ICPA(N,MaxFEs,lb,ub,dim,fobj)
Target=zeros(1,dim);
X=initialization(N,dim,ub,lb);
Target_fitness=fobj(X(1,:));
CV=[];
flag=1;
FEs=1;
t=1;
%% Dynamic sub-swarm number strategy
j = 1;
for i = 2 : N / 2
    if ( mod(N/i, 1) == 0 )
        NsubVector(j) = N / i;
        j = j + 1;
    end
end
NsubVector(j) = 1;
mm = 1;   
mark = 0;
Cgen = floor( MaxFEs/size(NsubVector, 2));   
Nsub = NsubVector(mm);
Ssub = N/Nsub;   
%%

SubSwarmIndex = randperm(N);  
Swarm = zeros(Nsub, Ssub, dim);   
k = 1;
for i = 1 : Nsub
    for j = 1 : Ssub
        Swarm(i, j, :) = X(SubSwarmIndex(k), :);
        k = k + 1;
    end
end
while FEs<=MaxFEs
    if mark==1
        mm = mm + 1;
        if mm > length(NsubVector)
            mm = length(NsubVector);
        end
        Nsub = NsubVector(mm);
        Ssub = N/Nsub;
        Swarm = zeros(Nsub, Ssub, dim); 
        SubSwarmIndex = randperm(N);
        k=1;
        for i = 1 : Nsub
            for j = 1 : Ssub
                Swarm(i, j, :) = X(SubSwarmIndex(k), :);
                k = k + 1;
            end
        end
        mark=0;
    end
    Target_set=[];
    Target_fitness_set=[];
    New_X_set=[];
    for i=1:size(Swarm,1)
        for j=1:size(Swarm,2)
            Sub_X(j,:) = Swarm(i,j,:);
        end
        Ssub_L = size(Swarm,2);
        [Sub_X,FEs,Target,Target_fitness,mark]=CPA_Kernel(Ssub_L,MaxFEs,lb,ub,dim,fobj,FEs,Sub_X,Target,Target_fitness,mark,Cgen);
        Target_set = [Target_set;Target];                      
        Target_fitness_set = [Target_fitness_set;Target_fitness];
        New_X_set = [New_X_set;Sub_X];             
    end
    %%  Covariance matrix adaptation evolution strategy
    [NewAllFitness,SmellIndex] = sort(Target_fitness_set);
    Alpha_pos = Target_set(SmellIndex(1));
    XX = New_X_set;
    m = dim;
    n = size(New_X_set,1);
    if flag == 1
        mean_alpha = Alpha_pos';
        Sum = sum(XX);
        x_ba = (1/n) .*Sum;
        for i=1:n
            dis(i) = sum((XX(i,:) - x_ba).^(2));
        end
        d_alpha = sum((Alpha_pos - x_ba).^2);
        cita_alpha = (d_alpha)/(sum(dis));
        mu = n/2;
        weights = log(mu+1/2)-log(1:mu)'; 
        mu = floor(mu); 
        weights = weights/sum(weights); 
        mueff=sum(weights)^2/sum(weights.^2);
        
        cc = (4+mueff/m) / (m+4 + 2*mueff/m);  
        cs = (mueff+2)/(m+mueff+5);
        c1 = 2 / ((m+1.3)^2+mueff); 
        cmu = 2 * (mueff-2+1/mueff) / ((m+2)^2+2*mueff/2); 
        damps = 1 + 2*max(0, sqrt((mueff-1)/(m+1))-1) + cs;
        pc = zeros(m,1); 
        ps = zeros(m,1); 
        B = eye(m); 
        D = eye(m); 
        C = B*D*(B*D)'; 
        chiN=m^0.5*(1-1/(4*m)+1/(21*m^2));
        flag = 0;
    end
    [X_alpha,mean_alpha,ps,pc,C,cita_alpha,B,D,FEs,mark] = CMS(mean_alpha,cita_alpha,mu,FEs,cc,cs,c1,cmu,damps,pc,ps,B,D,C,chiN,fobj,n,dim,weights,mueff,mark,Cgen);
    X_alpha=X_alpha';
    for i=1:size(X_alpha,1)
        Temp = X_alpha(i,:);
        FEs=FEs+1;
        if mod(FEs,Cgen)==0
            mark=1;
        end
        F_Temp = fobj(Temp);
        FEs=FEs+1;
        if mod(FEs,Cgen)==0
            mark=1;
        end
        F_i = fobj(New_X_set(i,:));
        if F_Temp < F_i
            New_X_set(i,:) = Temp;
            if F_Temp < NewAllFitness(1)
                Target = Temp;
                Target_fitness=F_Temp;
            end
        else
            break;
        end
    end
    %%
    SubSwarmIndex = randperm(N);
    k=1;
    for i = 1 : Nsub
        for j = 1 : Ssub
            Swarm(i, j, :) = New_X_set(SubSwarmIndex(k), :);
            k = k + 1;
        end
    end
    CV(t)=Target_fitness;
    t=t+1;
end
end


function [X,FEs,Target,Target_fitness,mark]=CPA_Kernel(N,MaxFEs,lb,ub,dim,fobj,FEs,X,Target,Target_fitness,mark,Cgen)
    for i=1:N
        FU=X(i,:)>ub;FL=X(i,:)<lb;X(i,:)=(X(i,:).*(~(FU+FL)))+ub.*FU+lb.*FL;
        fitness=fobj(X(i,:));
        if mod(FEs,Cgen)==0
            mark=1;
        end
        FEs=FEs+1;
        if fitness<Target_fitness
            Target_fitness=fitness;
            Target=X(i,:);
        end
    end
    a = exp(9-18*FEs/MaxFEs);
    S0 = a*(1-FEs/MaxFEs); 
    for j=1 : dim
        EG=X(:,j);     
        EG=sort(EG);
        i=round(rand()*(size(X,1))+0.5); 
        if rand()< FEs/MaxFEs
             X(i,:)=Target;
        end
            r=rand();
            X(i,j)=r*X(i,j)+(1-r)*(EG(1)+EG(2))/2; 
    end
    for i=1:N        
        S=2*S0*rand-S0; 
        l=rand();    
        if  abs(S) < 2*a/3 
            if  rand() > 0.5    
                X(i,:)=Target-S*(rand(1,dim)*(ub(1)-lb(1))+lb(1));
            else
                Dp=abs(Target-X(i,:));
                X(i,:)=Target-2*S*Dp*exp(l)*tan(l*pi/4);        
            end
        else
            distance=4*rand()-2;
            if abs(distance) < 1                        
                for j= 1:dim
                    P(j,:)=rand(1,dim)*X(i,j);
                    p_value(j,:)=fobj(P(j,:));
                    if mod(FEs,Cgen)==0
                        mark=1;
                    end
                    FEs=FEs+1;
                end
                [p_value,index]=sort(p_value);
                X(i,:)=P(index(1),:);
            else
                X_rand=rand(1,dim).*(ub(1)-lb(1))+lb(1);       
                D=abs(2*rand()*X_rand-X(i,:));
                X(i,:)=X_rand-S*D;
            end
        end
    end  
end

function [X,xmean,ps,pc,C,sigma,B,D,FEs,mark]= CMS(xmean,sigma,mu,FEs,cc,cs,c1,cmu,damps,pc,ps,B,D,C,chiN,fobj,lambda,N,weights,mueff,mark,Cgen)

    for k=1:lambda
        arz(:,k) = randn(N,1); 
        arx(:,k) = xmean + sigma * (B*D * arz(:,k)); 
        arfitness(k) = fobj(arx(:,k)'); 
        if mod(FEs,Cgen)==0
            mark=1;
        end
        FEs = FEs + 1;
    end

    [arfitnesss, arindex] = sort(arfitness); 
    xmean = arx(:,arindex(1:mu))*weights; 
    zmean = arz(:,arindex(1:mu))*weights; 
    
    ps = (1-cs)*ps + (sqrt(cs*(2-cs)*mueff)) * (B * zmean); 
    hsig = norm(ps)/sqrt(1-(1-cs)^(2*FEs/lambda))/chiN < 1.4+2/(N+1); 
    pc = (1-cc)*pc + hsig * sqrt(cc*(2-cc)*mueff) * (B*D*zmean); 
    
    C = (1-c1-cmu) * C ... 
        + c1 * (pc*pc' ... 
        + (1-hsig) * cc*(2-cc) * C) ... 
        + cmu ... 
        * (B*D*arz(:,arindex(1:mu))) ...
        * diag(weights) * (B*D*arz(:,arindex(1:mu)))';
    
    sigma = sigma * exp((cs/damps)*(norm(ps)/chiN - 1)); 
    
    C=triu(C)+triu(C,1)'; 
    [B,D] = eig(C);
    D = diag(sqrt(diag(D)));
    
    X = arx;
end
