% Developed in MATLAB R2014b
% Source codes demo version 1.0
%Author, inventor and programmer: Yutao Yang
%E-mail:15669770075@163.com
%---------------------------------------------------------
function [bestPositions,Convergence_curve]=ABHGS(N,MaxFEs,lb,ub,dim,fobj)
% disp('My HGS0722 is now tackling your problem')

tic
% initialize position
Popnumber=N/2;
FEs=0;
trial=zeros(1,Popnumber);
Foods=initialization(Popnumber,dim,ub,lb);
ObjVal=[];
for i=1:Popnumber
    FoodsLin=fobj(Foods(i,:));
    FEs=FEs+1;
    ObjVal = [ObjVal;FoodsLin];
end

bestPositions=zeros(1,dim);
tempPosition=zeros(N,dim);
Destination_fitness=inf;%change this to -inf for maximization problems
Worstest_fitness=-inf;
AllFitness = inf*ones(N,1);%record the fitness of all positions
VC1 = ones(N,1);%record the variation control of all positions

weight3 = ones(N,dim);%hungry weight of each position
weight4 = ones(N,dim);%hungry weight of each position

%Initialize the set of random solutions
X=initialization(N,dim,ub,lb);
% Convergence_curve=zeros(1,MaxFEs);
Convergence_curve=[];
% FEs=1;
 it=1;

hungry = zeros(1,size(X,1));%record the hungry of all positions
count=0;

% Main loop
while  FEs <= MaxFEs
    VC2 = 0.03; %The variable of variation control 

    sumHungry = 0;%record the sum of each hungry 
    
    %sort the fitness
    for i=1:size(X,1)
        % Check if solutions go outside the search space and bring them back
        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        AllFitness(i) = fobj(X(i,:));
        FEs=FEs+1;
    end
    [X,AllFitness,FEs] = BB(N,X,AllFitness,bestPositions,dim,fobj,FEs,ub,lb);
    [AllFitnessSorted,IndexSorted] = sort(AllFitness);
    bestFitness = AllFitnessSorted(1);
    worstFitness = AllFitnessSorted(size(X,1));
    
    %update the best fitness value and best position
    if bestFitness < Destination_fitness
        bestPositions=X(IndexSorted(1),:);
        Destination_fitness = bestFitness;
        count=0;
    end
    
    if worstFitness > Worstest_fitness
        Worstest_fitness = worstFitness;
    end
    
    for i = 1:size(X,1)
         %calculate the variation control of all positions
         VC1(i) = sech(abs(AllFitness(i)-Destination_fitness));    
         %calculate the hungry of each position
        if Destination_fitness == AllFitness(i)
            hungry(1,i) = 0;
            count = count+1;
            tempPosition(count,:)=X(i,:);
        else
            temprand = rand();
            c = (AllFitness(i)-Destination_fitness)/(Worstest_fitness-Destination_fitness)*temprand*2*(ub-lb);
            if c<100
                b=100*(1+temprand);
            else
                b=c;
            end   
            hungry(1,i) = hungry(1,i)+ max(b); 
            sumHungry = sumHungry + hungry(1,i);
        end
    end 
    
    %calculate the hungry weight of each position
    for i=1:size(X,1)
        for j=2:size(X,2)
                weight3(i,j) = (1-exp(-abs(hungry(1,i)-sumHungry)))*rand()*2;
                if rand()<VC2
                    weight4(i,j) = hungry(1,i)*size(X,1)/sumHungry*rand();
                else
                    weight4(i,j) = 1;
                end
        end
        
    end
    
    
    % Update the Position of search agents
    shrink=2*(1-FEs/MaxFEs); % a decreases linearly fron 2 to 0
    for i=1:size(X,1)
        if rand<VC2
            X(i,:) = X(i,j)*(1+randn(1));
        else
            A = randi([1,count]);
            for j=1:size(X,2)
                r = rand();
                vb = 2*shrink*r-shrink;%[-a,a]
                % Moving based on the bestPosition
                % The transformation range is controlled by weight3,bestPositions and X
                if r>VC1(i)
                    X(i,j) = weight4(i,j)*tempPosition(A,j)+vb*weight3(i,j)*abs(tempPosition(A,j)-X(i,j));
                else
                    X(i,j) = weight4(i,j)*tempPosition(A,j)-vb*weight3(i,j)*abs(tempPosition(A,j)-X(i,j));
                end
            end
        end
    end
    
    [ObjVal,Foods,trial,FEs] = ABCfunc3(N,Foods,ObjVal,lb,ub,dim,fobj,trial,FEs);
    for i= 1 :Popnumber
        C=randi([1,N]);
        if ObjVal(i)<AllFitness(C)
            X(C,:)=Foods(i,:);
            AllFitness(C)=ObjVal(i);
        end
%         else
%             posi=(1/ObjVal(i))/((1/ObjVal(i))+(1/AllFitness(C)));
%             for j=1:dim
%                 if rand()<posi
%                     X(C,j)=Foods(i,j);
%                 end
%             end
%         end
    end
    Convergence_curve(it)=Destination_fitness;
    it=it+1;
end
toc
end



