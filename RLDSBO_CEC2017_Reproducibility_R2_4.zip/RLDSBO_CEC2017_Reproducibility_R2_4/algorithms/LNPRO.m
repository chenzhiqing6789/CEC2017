
function [BestSolxx,BestCosts]=LNPRO(N,MaxFEs,LB,UB,pop_size,ObjFunc_ID)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Partial Reinforcement Optimizer: An Evolutionary Optimization Algorithm %
% version 1.0                                                             %
% Authiors:                                                               %
% Ahmad Taheri **, Keyvan RahimiZadeh, Amin Beheshti, Jan Baumbach,       %
% Ravipudi Venkata Rao, Seyedali Mirjalili, Amir H Gandomi                %
%                                                                         %
% ** E-mail:                                                              %
%          Ahmad.taheri@uni-hamburg.de                                    %
%          Ahmad.thr@gmail.com                                            %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialization
% --- Problem Definition ---
begin = cputime;
tic
%Obj_Func = @ YourObjFunc;         %  Objective Function
nVar = pop_size;                          %  Number of Decision Variables
LB =  LB .* ones(1,nVar);          %  Variables Lower Bound
UB =  UB .* ones(1,nVar);          %  Variables Upper Bound

% --- PRO Parameters ---
RR = 0.7;                          %  Reinforcement Rate (RR)
%MaxFEs = MaxFEs;                  %  Maximum Number of Function Evaluations
nPop = N;                   %  Population Size
FEs = 0;                           %  Function Evaluations counter
fitcount=1;
% --- Empty Structure for Individuals ---
empty_individual.Behaviors=[];
empty_individual.response=[];
empty_individual.Schedule=[];
%empty_individual.Fy=[];
%empty_individual.Gx=[];

% --- Initialize Population Array ---
pop = repmat(empty_individual, nPop, 1);
% --- Initialize Best Solution ---

BestCosts =[];
% --- Initialize Population ---
for i=1:nPop
    pop(i).Behaviors = LB+rand(1,nVar).*(UB-LB); %LB+rand(1,N).*(UB-LB);
    pop(i).Schedule = unifrnd(0.9,1,1,nVar);
    pop(i).response =  ObjFunc_ID(pop(i).Behaviors ) ; % CEC2017
    FEs=FEs+1;
    
    
end
% --- Sort pop ---
[~,SorteIndx] = sort([pop.response]);
pop = pop(SorteIndx);
% --- Set the Best Solution ---
BestSol = pop(1);

% --- Initialize Best Cost Record ---
BestCosts(1,fitcount) = BestSol.response;
fitcount=fitcount+1;
[~, sortedIndx] = sort([pop.response]);

ResetZero = zeros(1,N);

%% --- PRO Main Loop ---
while FEs < MaxFEs
    
    for i=1:nPop  % For all Learners
        tempBehav = pop(i);% empty_individual;
        
        k = nPop;
        if i < nPop
            randi([i+1 nPop]);
        end
        
        %% --- Determine Behaviors of the ith learner based on Scheduler. -----------
        
        % According to Eq.(1) & Eq.(2)
        
        Tau = (FEs/MaxFEs);                          %  Time parameter+
        Tau=min(1,Tau);
        %Selection_rate = Tau^0.5;
        Selection_rate = exp(-(1-Tau)); %********
        %Selection_rate = exp(-(Tau))^2;
        [~,Candid_Behavs] = sort(pop(i).Schedule(1:nVar),'descend');
        % --Select Landa number of Behaviors with highest priority in Schedule i.--
        Landa = ceil(nVar*rand*Selection_rate);
        Selected_behaviors = Candid_Behavs(1:Landa);%
        
        %% --- Stimulate the selected Behaviors of the ith learner to get response.---
        % According to Eq.(3), Eq.(4), and Eq.(5)
        
        if rand <  0.5 %(0.1 + 0.9 * (1-Tau))
            Stimulation = ResetZero;
            Stimulation(Selected_behaviors) = ( BestSol.Behaviors(Selected_behaviors) - pop(i).Behaviors(Selected_behaviors));
        else
            Stimulation = ResetZero;
            Stimulation(Selected_behaviors) = ( pop(i).Behaviors(Selected_behaviors) - pop(k).Behaviors(Selected_behaviors));
        end
        
        % ---- Calculate Stimulation Factor (SF) ------
        %SF = rand * ( exp(-1 * mean( abs(BestSol.Behaviors - pop(i).Behaviors)/max(abs(pop(1).Behaviors - pop(nPop).Behaviors)))));
        %SF = rand * ( exp(-1 * mean( abs(BestSol.Behaviors(Selected_behaviors) - pop(i).Schedule(Selected_behaviors))/max(abs(pop(i).Schedule(Selected_behaviors) - pop(nPop).Schedule(Selected_behaviors))))));
        SF = Tau + rand * (mean((pop(i).Schedule(Selected_behaviors) )/max(abs(pop(i).Schedule)))); %(exp(-(1-FEs/MaxFEs))^2 ) ;
        
        tempBehav.Behaviors(Selected_behaviors) = pop(i).Behaviors(Selected_behaviors) + SF .* Stimulation(Selected_behaviors);
        
        % ------------  Bound constraints control -------------------
        %
        [~,underLB] = find(tempBehav.Behaviors < LB);
        [~,uperUB] = find(tempBehav.Behaviors > UB);
        if ~isempty(underLB)
            tempBehav.Behaviors(underLB) =  LB(underLB) + rand(1,size(underLB,2)).*((UB(underLB) -  LB(underLB))./1);
        end
        if ~isempty(uperUB)
            tempBehav.Behaviors(uperUB) =  LB(uperUB) + rand(1,size(uperUB,2)).*((UB(uperUB) -  LB(uperUB))./1);
        end
        
        % ------ Evaluate the ith learner Response -------------------
        %tempBehav.response = feval('cec14_func',tempBehav.Behaviors',ObjFunc_ID)  - (ObjFunc_ID*100);
        
        tempBehav.response = ObjFunc_ID(tempBehav.Behaviors); %CEC2017
        FEs=FEs+1;
        
        % ----- Apply Positive or Negative Reinforcement according to the response.
        
        % According to  Eq.(6)& Eq.(7)
        
        if tempBehav.response<pop(i).response
            % Positive Reinforcement
            tempBehav.Schedule(Selected_behaviors) = pop(i).Schedule(Selected_behaviors) + pop(i).Schedule(Selected_behaviors) * (RR/2);
            
            % accept new Solution
            pop(i) = tempBehav;
            
            % Update the best Solution
            if pop(i).response < BestSol.response
                BestSol = pop(i);
            end
            
        else
            % Negative Reinforcement
            pop(i).Schedule(Selected_behaviors) = pop(i).Schedule(Selected_behaviors) - pop(i).Schedule(Selected_behaviors) * (RR);
        end
        
        
        
        
        
        %% ------- Rescheduling --------------------------------------------------
        if std(pop(i).Schedule(1:nVar))== 0
            pop(i).Schedule = unifrnd(0.9,1,1,nVar);
            pop(i).Behaviors = LB+rand(1,nVar).*(UB-LB);
            %pop(i).response = feval('cec14_func',pop(i).Behaviors',ObjFunc_ID)  - (ObjFunc_ID*100);
            pop(i).response = ObjFunc_ID(pop(i).Behaviors); %CEC2017
            FEs=FEs+1;
            
        end
        
        
    end % End for nPop
    
    %%%%%%%%%%%% student phase %%%%%%%%%%%%%%%%%%
    for i = 1:nPop
        j = randi(nPop);
        while j == i
            j = randi(nPop);
        end
        if pop(i).response < pop(j).response
            pop_new = pop(i).Behaviors + Levy(nVar).* (pop(i).Behaviors - pop(j).Behaviors);
        else
            pop_new = pop(j).Behaviors + Levy(nVar) .* (pop(j).Behaviors - pop(i).Behaviors);
        end
        
        
        FU=pop_new>UB;FL=pop_new<LB;pop_new=(pop_new.*(~(FU+FL)))+UB.*FU+LB.*FL;
        fitnessNew = ObjFunc_ID(pop_new);
        FEs = FEs + 1;
        if fitnessNew < pop(1).response
            pop(1).response = fitnessNew;
            pop(1).Behaviors = pop_new;
            if pop(1).response < BestSol.response
                BestSol = pop(1);
            end
        end
        
        if fitnessNew < pop(i).response
            pop(i).response = fitnessNew;
            pop(i).Behaviors = pop_new;
        end
    end
    

    
    
    
    
    
    %% Sort pop
    [~,SorteIndx] = sort([pop.response]);
    pop = pop(SorteIndx);
    
    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%NMs%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    options = optimset('MaxFunEvals', floor(MaxFEs * 0.03));
    [x, fval, ~, output]  = fminsearchbnd(ObjFunc_ID, pop(1).Behaviors,LB,UB,options);
    if fval <   pop(1).response
         pop(1).response = fval;
         pop(1).Behaviors = x;
         BestSol= pop(1);
    end
    FEs = FEs + output.funcCount;
    BestCosts(1,fitcount) = BestSol.response;
        fitcount = fitcount + 1;
%     
    
end % End While
BestSolxx=BestSol.Behaviors;


end % Function PRO_v1()
% A funtion to determine a random number
%with uniform distribution (unifrnd function in Matlab)
function z=Unifrnd(a,b,c,dim)
a2 = a/2;
b2 = b/2;
mu = a2+b2;
sig = b2-a2;
z = mu + sig .* (2*rand(c,dim)-1);
end
function o=Levy(d)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;v=randn(1,d);step=u./abs(v).^(1/beta);
o=step;
end
% A function to determine thress random indices of solutions
function [A,B,C]=RndX(nP,i)
Qi=randperm(nP);Qi(Qi==i)=[];
A=Qi(1);B=Qi(2);C=Qi(3);
end