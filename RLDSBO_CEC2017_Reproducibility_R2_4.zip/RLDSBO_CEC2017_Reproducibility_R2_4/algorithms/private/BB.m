
function [P,Objective_values,fes] = BB(N,ant_position,Objective_values,Elite_antlion_position,dim,fobj,fes,ub,lb)
%%骨架变异
%N = n;
    for i=1:N
%         Objective_values(1,i)=fobj(ant_position(i,:));
        
        %           CR = 1-exp(-abs(Objective_values(1,i)-Destination_fitness));%%变异控制变量
        CR = 0.9;
        [k1,k2,k3] = GetRan3( i,N );
        k=rand();
        for j=1:dim
            if rand()<CR
                mu=(Elite_antlion_position(j)+ant_position(i,j))/2;
                sigma=abs(Elite_antlion_position(j)-ant_position(i,j));
                V(i,j)=normrnd(mu,sigma);
            else
                V(i,j)=ant_position(k1,j)+k*(ant_position(k2,j)-ant_position(k3,j));%%DE/best/1
            end
        end
        Flag4ub=V(i,:)>ub;
        Flag4lb=V(i,:)<lb;
        V(i,:)=(V(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        Vfitness(i)=fobj(V(i,:));
        fes = fes + 1;
        if Vfitness(i)<Objective_values(i)
            ant_position(i,:)=V(i,:);
            Objective_values(i)=Vfitness(i);
        end
       
    end
    %%骨架变异结束
    
    P = ant_position;
    

    
end