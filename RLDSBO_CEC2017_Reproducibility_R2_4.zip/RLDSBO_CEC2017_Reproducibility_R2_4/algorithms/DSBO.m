

function [best_pos, Convergence_curve] = DSBO(N, Max_FEs, lb, ub, dim, fobj)

    %INITIALIZATION
    Convergence_curve = [];
    FEs = 0;
    
    current_X = initialization(N, dim, ub, lb);
    current_Fitness = inf * ones(N, 1);
    
    for i = 1:N
        current_Fitness(i, 1) = fobj(current_X(i, :));
        FEs = FEs + 1;
    end
    
    [bestFitness, best_idx] = min(current_Fitness);
    best_pos = current_X(best_idx, :);
    
    %% --- ENHANCEMENT 1: Reinforcement Learning (RL) Setup ---
    num_actions = 2; % Action 1: Exploration (DE), Action 2: Exploitation (SBO-like)
    Q_table = zeros(N, num_actions); % Q-table for each agent
    learning_rate = 0.5; % Alpha
    discount_factor = 0.9; % Gamma (not critical in this stateless version)
    epsilon = 0.5; % Initial exploration rate for action selection
    
    %% --- ENHANCEMENT 2: L-SHADE Parameter Adaptation Setup ---
    memory_size = N;
    M_F = 0.5 * ones(memory_size, 1); % Memory for scaling factor F
    M_CR = 0.5 * ones(memory_size, 1); % Memory for crossover rate CR
    mu_F = 0.5;
    mu_CR = 0.5;
    archive = []; % Archive for storing improved solutions
    archive_size_limit = 2 * N;
    k = 1; % Memory index
    
    %% --- ENHANCEMENT 3: Lens Opposition-Based Learning (OBL) Setup ---
    stagnation_counter = 0;
    stagnation_threshold = 30; % Trigger OBL after 30 iterations without improvement
    
	iter = 1;
    
    while FEs < Max_FEs
        
        S_F = []; % To store successful F values in this generation
        S_CR = []; % To store successful CR values in this generation
        
        % Update archive
        archive = [archive; current_X];
        if size(archive, 1) > archive_size_limit
            rand_indices = randperm(size(archive, 1));
            archive = archive(rand_indices(1:archive_size_limit), :);
        end
        
        for i = 1:N
            %% --- RL: Action Selection (Epsilon-Greedy) ---
            if rand < epsilon
                action = randi(num_actions); % Explore: choose a random action
            else
                [~, action] = max(Q_table(i, :)); % Exploit: choose the best-known action
            end
            
            %% --- L-SHADE: Generate Parameters F and CR ---
            % Generate CR
            cr_idx = randi(memory_size);
            CR = normrnd(M_CR(cr_idx), 0.1);
            CR = min(1, max(0, CR));
            
            % Generate F
            f_idx = randi(memory_size);
            F = -1;
            while F <= 0 % F must be positive
                F = cauchy_rnd(M_F(f_idx), 0.1);
            end
            F = min(1, F);
            
            %% Generate Trial Vector based on the selected action
            trial_X = zeros(1, dim);
            
%             if action == 1 % Action 1: Exploration using 'DE/current-to-pbest/1'
                % Select pbest from top 10%
                p = 0.1;
                p_best_count = max(2, ceil(p*N));
                [~, sorted_indices] = sort(current_Fitness);
                pbest_idx = sorted_indices(randi(p_best_count));
                p_best_pos = current_X(pbest_idx, :);

                % Select r1 and r2
                r1_idx = randi(N); while r1_idx == i, r1_idx = randi(N); end
                r2_idx = randi(size(archive, 1)); while r2_idx == i, r2_idx = randi(size(archive, 1)); end
                
                v = current_X(i, :) + F * (p_best_pos - current_X(i, :)) + F * (current_X(r1_idx, :) - archive(r2_idx, :));

                % Binomial Crossover
                j_rand = randi(dim);
                for j = 1:dim
                    if rand < CR || j == j_rand
                        trial_X(j) = v(j);
                    else
                        trial_X(j) = current_X(i, j);
                    end
                end

%             else % Action 2: Exploitation using an SBO-like operator
                Rolette_index = RouletteWheelSelection(1./current_Fitness);
                if Rolette_index == -1, Rolette_index = best_idx; end
                
                r1 = randn;
                r2 = randn;
                r3 = tanh((sqrt(abs(Max_FEs - randn * FEs))/iter)^(FEs/Max_FEs));
                
                for j = 1:dim
                    trial_X(j) = (1 - r1 - r2) * current_X(i, j) + r1 * current_X(Rolette_index, j) + r2 * best_pos(j);
                    if rand > r3
                        trial_X(j) = trial_X(j) * r3 * randn; % Add perturbation
                    end
                end
%             end
            
            %% Boundary control
            trial_X = BoundaryControl(trial_X, lb, ub);
            
            %% Greedy Selection & Updates
            trial_Fitness = fobj(trial_X);
            FEs = FEs + 1;
           
%             reward = 0;
            if trial_Fitness < current_Fitness(i)
                % Success
                current_X(i, :) = trial_X;
                current_Fitness(i) = trial_Fitness;
                reward = 1; % Positive reward for improvement
                
                % L-SHADE: Store successful parameters
                if action == 1
                    S_F(end+1) = F;
                    S_CR(end+1) = CR;
                end
                
                % Update global best if necessary
                if trial_Fitness < bestFitness
                    bestFitness = trial_Fitness;
                    best_pos = trial_X;
                    stagnation_counter = 0; % Reset stagnation counter on improvement
                end
            else
                % Failure
                reward = 0; % No reward for no improvement
                stagnation_counter = stagnation_counter + 1/N; % Increment stagnation counter
            end
            
            %% RL: Update Q-table
            % Simplified Q-learning update (since state is static per iteration)
            Q_table(i, action) = (1 - learning_rate) * Q_table(i, action) + learning_rate * reward;
        end
        
        %% --- L-SHADE: Update Parameter Memory ---
        if ~isempty(S_F)
            mu_F = (sum(S_F.^2) / sum(S_F)); % Lehmer mean for F
            M_F(k) = mu_F;
        end
        if ~isempty(S_CR)
            mu_CR = mean(S_CR); % Arithmetic mean for CR
            M_CR(k) = mu_CR;
        end
        k = k + 1;
        if k > memory_size, k = 1; end
        
%         %% --- OBL: Trigger if stagnated ---
%         if stagnation_counter >= stagnation_threshold
%             % Generate lens-opposite solution
%             k_obl = rand(); % Dynamic factor
%             mid_point = (lb + ub) / 2;
%             lens_opposite_pos = mid_point + k_obl * (mid_point - best_pos);
%             
%             lens_opposite_pos = BoundaryControl(lens_opposite_pos, lb, ub);
%             
%             lens_fitness = fobj(lens_opposite_pos);
%             FEs = FEs + 1;
%             
%             if lens_fitness < bestFitness
%                 best_pos = lens_opposite_pos;
%                 bestFitness = lens_fitness;
%                 % Replace the worst individual with the OBL solution
%                 [~, worst_idx] = max(current_Fitness);
%                 current_X(worst_idx, :) = best_pos;
%                 current_Fitness(worst_idx) = bestFitness;
%             end
%             stagnation_counter = 0; % Reset counter after applying OBL
%         end
        
        Convergence_curve(iter) = bestFitness;
        iter = iter + 1;
        epsilon = epsilon * 0.99; % Decay epsilon over time
    end
end  

%% --- Helper Functions ---

function X = initialization(N, dim, ub, lb)
    Boundary_no = size(ub, 2); % Number of boundaries
    if Boundary_no == 1
        X = rand(N, dim) .* (ub - lb) + lb;
    else
        X = zeros(N, dim);
        for i = 1:N
            for j = 1:dim
                X(i, j) = rand .* (ub(j) - lb(j)) + lb(j);
            end
        end
    end
end

function X = BoundaryControl(X, low, up)
    [~, dim] = size(X);
    if numel(low) == 1 % Single boundary for all dimensions
        X(X < low) = low;
        X(X > up) = up;
    else % Boundary for each dimension
        for j=1:dim
            if X(j) < low(j), X(j) = low(j); end
            if X(j) > up(j), X(j) = up(j); end
        end
    end
end
    
function choice = RouletteWheelSelection(weights)
  weights(isinf(weights)) = 1e10; % Handle potential inf from 1/0
  weights(isnan(weights)) = 1e-10;
  if sum(weights) == 0
      choice = -1;
      return;
  end
  accumulation = cumsum(weights);
  if accumulation(end) == 0
      choice = -1;
      return;
  end
  p = rand() * accumulation(end);
  chosen_index = -1;
  for index = 1:length(accumulation)
    if (accumulation(index) > p)
      chosen_index = index;
      break;
    end
  end
  choice = chosen_index;
end  

function r = cauchy_rnd(mu, gamma)
    % Generates a random number from a Cauchy distribution
    r = mu + gamma * tan(pi * (rand - 0.5));
end

