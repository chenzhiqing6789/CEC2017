function validation = run_validation()
%RUN_VALIDATION Real benchmark smoke checks, not paper experiment evidence.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(root);
[~,setupGuard]=repro.setup();
cfg=cec2017_config(); cfg.maxFEs=3000; cfg.tracePoints=31; cfg.runs=2;
functions=[1 10 11 25]; rows=table();
for f=functions
    for a=1:numel(cfg.algorithms)
        name=cfg.algorithms{a};
        fprintf('SMOKE F%02d %s\n',f,name);
        r=repro.run_one(cfg,name,f,1);
        assert(r.actualFEs<=cfg.maxFEs && isfinite(r.fitness));
        assert(all(r.bestPosition>=cfg.lowerBound & r.bestPosition<=cfg.upperBound));
        assert(all(diff(r.traceFitness)<=0));
        verified=cec17_func(r.bestPosition(:),f);
        assert(abs(verified-r.fitness)<=1e-12*max(1,abs(r.fitness)));
        if f==10
            repeat=repro.run_one(cfg,name,f,1);
            assert(isequaln(r.traceFitness,repeat.traceFitness) && isequal(r.bestPosition,repeat.bestPosition) ...
                && r.actualFEs==repeat.actualFEs,'repro:Determinism','Seed repeat failed for %s',name);
        end
        rows=[rows;repro.result_row(r)]; %#ok<AGROW>
    end
end
out=fullfile(root,'validation'); if ~isfolder(out), mkdir(out); end
writetable(rows,fullfile(out,'smoke_only_not_paper_results.csv'));
% Every algorithm must accept a budget not divisible by the population size.
cfg.maxFEs=3001;
for a=1:numel(cfg.algorithms)
    r=repro.run_one(cfg,cfg.algorithms{a},10,2);
    assert(r.actualFEs<=3001 && isfinite(r.fitness));
end
% Serialization/resume, changed-config rejection, and complete run-grid checks.
cfg.algorithms={'RLDSBO','SBO'}; cfg.functions=[1 10]; cfg.maxFEs=93;
cfg.tracePoints=9; cfg.outputDir=tempname; cleanup=onCleanup(@() remove_temp(cfg.outputDir));
raw=run_cec2017(cfg); again=run_cec2017(cfg); assert(isequaln(raw,again));
csvRaw=readtable(fullfile(cfg.outputDir,'raw_final_fitness.csv'),'TextType','string');
assert(isequal(raw.Fitness,csvRaw.Fitness),'repro:Precision','CSV fitness precision was lost.');
assert(all(raw.ActualFEs<=93)); analyze_results(raw,cfg.outputDir,'RLDSBO');
changed=cfg; changed.maxFEs=94; expect_error(@() run_cec2017(changed),'repro:ResumeMismatch');
expect_error(@() analyze_results([raw;raw(1,:)],'', 'RLDSBO'),'repro:Duplicate');
expect_error(@() analyze_results(raw(2:end,:),'','RLDSBO'),'repro:Incomplete');
bad=raw; bad.Fitness(1)=NaN; expect_error(@() analyze_results(bad,'','RLDSBO'),'repro:Data');
same=raw; same.Fitness(:)=1; stats=analyze_results(same,'','RLDSBO');
assert(all(stats.comparisons.PValueUnadjusted==1) && stats.friedmanP==1 ...
    && all(stats.rankSummary.AverageRankOfFunctionMeans==1.5));
archived=reproduce_archived_results();
validation=struct('passed',true,'matlab',version,'smokeRuns',height(rows), ...
    'repeatSeedChecks',15,'nonDivisibleBudgetChecks',15, ...
    'smokeBudget',3000,'functions',functions,'archiveRecords',4500, ...
    'note','Smoke runs are software validation only, not the missing historical comparison data.', ...
    'archivedRanks',archived.rankSummary,'archivedCounts',archived.winLoss);
save(fullfile(out,'validation.mat'),'validation');
fid=fopen(fullfile(out,'validation.json'),'w','n','UTF-8');
fprintf(fid,'%s',jsonencode(validation,'PrettyPrint',true)); fclose(fid);
disp('ALL REPRODUCIBILITY VALIDATION CHECKS PASSED');
end
function expect_error(fn,id)
try, fn(); catch err, assert(strcmp(err.identifier,id),'Unexpected error: %s',err.identifier); return; end
error('repro:Test','Expected error %s was not raised.',id);
end
function remove_temp(folder)
% Only remove this test's explicitly created unique temp directory.
if isfolder(folder), rmdir(folder,'s'); end
end
