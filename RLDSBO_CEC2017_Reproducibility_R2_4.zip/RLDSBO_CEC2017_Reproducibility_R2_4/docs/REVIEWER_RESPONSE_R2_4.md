# R2.4 代码与实验可复现性回复

以下回复对应随附文件中的实际内容。历史数据复算与新运行入口分别说明；数值验证结果不代替完整论文实验。

## R2.4.1

中文回复：感谢审稿人关于逐次结果可核查性的建议。随附复现包已整理RLDSBO、RLDSBO-Rand50、RL-HPSDE、DSBO和SBO在CEC2017全部30个函数上每函数30次独立运行的4500条原始最终适应度，并保留原始工作簿、CSV导出和40点采样收敛记录。MATLAB入口可直接将这些记录转存为MAT文件并重新生成表A1–A2统计。复算与原表一致，RLDSBO平均排名为1.500，相对RL-HPSDE为29胜、0负、1项不显著，相对Rand50为6胜、2负、22项不显著。这使支撑相关性能比较的逐次数据可以直接检查。表A3–A6另外10种算法的历史逐次文件未保留，因此本次提供其完整代码及新运行入口，不将汇总值反推为原始数据，也不声称已恢复这些历史记录。

English response: Thank you for requesting verifiable run-level results. The accompanying reproducibility package contains 4,500 original final-fitness records for RLDSBO, RLDSBO-Rand50, RL-HPSDE, DSBO and SBO, covering all 30 CEC2017 functions with 30 independent runs per function. It preserves the original workbook, CSV exports and 40-point sampled convergence records. A MATLAB entry point also saves the archived records in MAT format and regenerates the A1–A2 statistics. Recalculation agrees with the reported results: RLDSBO has an average rank of 1.500, with 29 wins, no losses and one nonsignificant case against RL-HPSDE, and 6 wins, 2 losses and 22 nonsignificant cases against Rand50. These records make the evidence for these comparisons directly inspectable. Historical run-level files for the other ten comparators in Tables A3–A6 were not retained; we supply their complete code and a new-run entry point without reconstructing raw observations from summary statistics or claiming recovery of those historical records.

修改内容：随附原始工作簿、4500条最终适应度CSV、原始采样轨迹及来源校验记录；增加历史记录转存与统计复算入口。论文已有数值不变。

修改位置：第4节实验协议说明；Data Availability末段；随附RLDSBO_CEC2017_Reproducibility_R2_4/data/archived_5alg_30runs/、reproduce_archived_results.m及results/archived_5alg_statistics/。

## R2.4.2

中文回复：感谢审稿人的建议。复现包已提供analyze_results.m，统一计算逐函数均值、样本标准差、双侧Wilcoxon符号秩p值、逐函数均值排名和Friedman统计。均值和标准差使用原始最终适应度及std(x,0)；Wilcoxon按相同运行编号配对，采用未经多重比较校正的0.05阈值；排名对每个函数的算法均值作升序平均秩，再跨函数取平均，Friedman以函数为区组，避免混淆不同统计口径。脚本核查重复键、缺失运行及非有限数值。使用已有4500条记录复算后，表A1的300个均值/标准差单元格和表A2的120个p值及结果单元格均在论文显示精度下一致，平均排名及胜负计数也一致。统计脚本因此可直接核查本文五算法比较中所报告的解质量、变异性和相对表现。

English response: Thank you for this suggestion. We provide analyze_results.m to compute per-function means, sample standard deviations, two-sided Wilcoxon signed-rank p-values, ranks of per-function means and Friedman statistics. Standard deviations use std(x,0). Signed-rank tests pair matching run indices and use the reported unadjusted 0.05 threshold. Algorithms receive ascending midranks within each function based on their mean final fitness, and these ranks are averaged across functions; the Friedman test uses functions as blocks. This explicitly separates the relevant statistical definitions. The script rejects duplicate keys, missing runs and nonfinite values. Recalculation from the 4,500 archived records agrees, at the displayed precision, with all 300 mean/standard-deviation cells in Table A1 and all 120 p-value/outcome cells in Table A2. The average ranks and win/loss counts also agree. The scripts therefore directly verify the reported solution quality, variability and relative performance in the five-method comparison.

修改内容：增加统一统计脚本、均值/标准差、Wilcoxon、排名及Friedman输出；核对表A1–A2共420个数值及检验结论单元格，未修改原表数据。

修改位置：第4节实验协议说明；Data Availability末段；随附analyze_results.m、results/archived_5alg_statistics/及validation/paper_table_audit.json。

## R2.4.3

中文回复：感谢审稿人对可执行实现的具体要求。随附精简包包含RLDSBO、SBO、DSBO及全部10种指定对比算法EESHHO、GDTSCA、ICPA、LNPRO、ABHGS、JADE、LSHADE-cnEpSi、SADE、EBOwithCMAR和MPEDE的完整本地MATLAB源码与必要依赖，同时保留表A1–A2使用的Rand50和RL-HPSDE。run_cec2017.m提供统一执行、种子记录、逐次检查点和实际FE预算控制，README说明历史表格复算与新表/图生成步骤。源码清单记录原相对路径及整理前后SHA-256，保留已有作者/出处信息，并列明去除时钟重设种子、函数名修正、预算同步及非整代数组分配等实际改动；缺少上游发布版本记录的文件以提供的本地快照识别。RL-HPSDE明确标为基于已注明MetaBox commit的MATLAB移植。全部15种算法已在F1、F10、F11和F25通过小预算运行验证，并通过种子重复及非整代预算检查。这些是代码验证，不替代论文完整预算实验。新入口的严格实际FE上限和最佳可行观测口径另作标识，不与历史记录混用。

English response: Thank you for specifying the executable materials required. The compact package contains complete local MATLAB sources and necessary dependencies for RLDSBO, SBO, DSBO and all ten requested comparators: EESHHO, GDTSCA, ICPA, LNPRO, ABHGS, JADE, LSHADE-cnEpSi, SADE, EBOwithCMAR and MPEDE. It also includes Rand50 and RL-HPSDE used in Tables A1–A2. The run_cec2017.m entry point provides seed logging, per-run checkpoints and actual function-evaluation control; the README explains archived-table reproduction and generation of new tables and curves. The source manifest records original paths and SHA-256 checksums before and after packaging, retains available author/source information, and documents removal of clock-based reseeding, function-name correction, budget synchronization and integer allocation for non-divisible budgets. Files lacking upstream release identifiers are identified as the supplied local snapshots. RL-HPSDE is explicitly identified as a MATLAB port based on the recorded MetaBox commit. All 15 methods passed small-budget execution checks on F1, F10, F11 and F25, repeated-seed checks and non-divisible-budget checks. These checks validate software execution and do not replace full-budget experiments. The new runner explicitly labels its strict actual-FE limit and best-feasible-observation metric, keeping these records separate from historical results.

修改内容：提供15算法精简源码及必要依赖、CEC2017 D30基准文件、统一入口、README、源码校验清单、逐项代码差异和第三方来源记录；完成真实基准函数软件验证。未将验证结果写入论文实验表。

修改位置：Data Availability末段；随附README.md、run_cec2017.m、algorithms/、benchmark/、docs/SOURCE_MANIFEST.csv、docs/SOURCE_CHANGES.patch、docs/THIRD_PARTY_SOURCES.md和validation/。

## R2.4.4

中文回复：感谢审稿人的建议。复现包通过cec2017_config.m集中列出D=30、边界[-100,100]、名义种群输入N=30、最大300000次实际目标函数调用以及默认30次独立运行，并在ALGORITHM_PARAMETERS.md逐项记录算法特有参数及其源码位置。例如，RLDSBO采用α=0.5、初始ε=0.5和逐代0.99衰减、长度N的成功历史记忆及最大2N档案；JADE采用c=0.1、p=0.05；RL-HPSDE采用α=0.8、γ=0.5。文档还明确动态种群和附加子群安排，例如EBOwithCMAR在D=30时含N个DE个体和14个CMA个体，不把相同输入N误写为各算法始终具有相同有效种群。预算、种子和源文件校验值随新实验一起保存，从而使比较设置可检查、可重复执行。

English response: Thank you for this recommendation. The cec2017_config.m file centrally specifies D=30, bounds of [-100,100], nominal population input N=30, a maximum of 300,000 actual objective calls and a default of 30 independent runs. ALGORITHM_PARAMETERS.md documents algorithm-specific settings and their source locations. For example, RLDSBO uses alpha=0.5, initial epsilon=0.5 with a per-generation factor of 0.99, a success-history memory of length N and an archive limit of 2N; JADE uses c=0.1 and p=0.05; RL-HPSDE uses alpha=0.8 and gamma=0.5. The document also specifies population reduction and additional subpopulations. At D=30, EBOwithCMAR starts with N DE individuals and 14 CMA individuals, so a common input N is not presented as an identical effective population for every method. The budget, seeds and source checksums are saved with each new experiment, making its settings inspectable and repeatable.

修改内容：增加集中配置文件及逐算法参数说明，区分名义输入种群与算法实际子群/递减机制，记录新实验预算、随机种子及源码版本。

修改位置：Data Availability末段；随附cec2017_config.m、docs/ALGORITHM_PARAMETERS.md和新实验生成的experiment.mat/experiment.json。

## R2.4.5

中文回复：感谢审稿人关于独立运行次数的建议。新的统一入口默认设置cfg.runs=30，并允许显式调整，配置文件与每次运行记录一同保存。表A1–A2的五算法已有数据确为每函数30次独立运行，相关均值、标准差和检验已由4500条记录复算核对。脚本对每一函数、算法及运行编号建立完整网格，并拒绝将缺失或失败运行静默排除。表A3–A6保留原20次实验的明确标识；其另外10种算法没有历史逐次文件，本次提供默认30次的新运行入口，不把默认设置或小预算代码检查表述为已经完成新的30次完整实验。

English response: Thank you for recommending an explicit independent-run count. The new entry point defaults to cfg.runs=30 and permits explicit adjustment, with the configuration saved alongside the run records. The archived five-method data for Tables A1–A2 do contain 30 independent runs per function; their means, standard deviations and tests have been checked from all 4,500 records. The analysis validates a complete function–algorithm–run grid and does not silently discard missing or failed trials. Tables A3–A6 retain their explicit original 20-run designation. Since historical run-level files for their other ten comparators are unavailable, we provide a default 30-run generation entry point without presenting this default or the small-budget software checks as completed new 30-run full-budget experiments.

修改内容：增加可调运行次数、默认30次、记录完整性校验和断点续跑；保留30次五算法数据与原20次比较的区分，不改变已有实验数值。

修改位置：第4节实验协议说明；随附cec2017_config.m、run_cec2017.m、analyze_results.m及README“已有数据覆盖范围”和“重新运行的最小示例”。
