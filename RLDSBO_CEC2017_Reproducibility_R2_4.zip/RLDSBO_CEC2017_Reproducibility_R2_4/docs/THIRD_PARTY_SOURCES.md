# 源码版本与出处记录

本包以作者提供框架中的实际文件为版本依据。`SOURCE_MANIFEST.csv` 给出每个算法和辅助函数的**完整原SHA-256、原相对路径、整理后SHA-256**；这能精确识别本次使用的本地快照。来源头部未给出上游commit或发布版本的，明确记为“上游版本未记录”，不据算法名称猜测官方版本。以下链接为提供源码已有的出处线索，并非声明本包从该链接下载了最新文件。

| 算法/部件 | 原文件位置或已记录出处 | 版本识别 |
|---|---|---|
| RLDSBO | `chendashen/qCLSBO/RLDSBO.m` | 原SHA-256：cb945b8a731563770ff443a455a6f15e0beb7e4c55a688f866ff58e257ec2181 |
| SBO | `Origin/SBO.m`；头部Wang et al., The Status-based Optimization: Algorithm and comprehensive performance analysis；标注2025-05-24 | SHA-256见manifest；上游commit未记录 |
| DSBO、Rand50 | `chendashen/qCLSBO/DSBO.m`、`RLDSBO_Rand50.m` | 本地对照版本，SHA-256见manifest |
| EESHHO | `new/EESHHO/EESHHO.m`；头部demo version 1.0；https://doi.org/10.1016/j.eswa.2020.114529 ；https://aliasgharheidari.com/publications/EESHHO.html | 本地适配快照SHA-256见manifest；原发布commit未记录 |
| GDTSCA | `new/GDTSCA.m` | 上游版本/下载链接未记录；精确本地快照见manifest |
| ICPA | `new/ICPA.m` | 上游版本/下载链接未记录；精确本地快照见manifest |
| LNPRO | `new/LNPRO.m`，原声明PRO_v1 | 上游版本/下载链接未记录；精确本地快照见manifest |
| ABHGS | `chendashen/AHGS改/ABHGS.m`；头部Yutao Yang、demo version 1.0 | 配套辅助函数以原路径实际优先级解析；每项SHA-256见manifest |
| JADE | `winner/JADE/JADE.m`；源码头部标明modified code，http://ist.csu.edu.cn/YongWang.htm | 上游commit未记录；不将该本地适配称为未经修改的官方实现 |
| LSHADE-cnEpSi | `improved/LSHADE_cnEpSi.m`；头部Awad, Ali, Suganthan, CEC2017及LSHADE-EpSin论文说明 | 上游commit/下载链接未记录；源码保留原归属 |
| SADE | `improved/SADE/SADE.m`；Qin, Huang, Suganthan (2009)；http://ist.csu.edu.cn/YongWang.htm | 头部标明modified code；本地SHA-256见manifest |
| EBOwithCMAR | `winner/EBOwithCMAR.m`；包含UMOEA-II及Hansen CMA-ES来源说明，https://www.lri.fr/~hansen/cmaes_inmatlab.html#matlab | 上游commit未记录；源码内原声明保留 |
| MPEDE | `improved/MPEDE.m`；Guohua Wu et al.；https://doi.org/10.1016/j.ins.2015.09.009 | 源码头部注明已有优化改动；本地SHA-256见manifest |
| RL-HPSDE | `chendashen/qCLSBO/RL_HPSDE.m`；https://doi.org/10.1016/j.swevo.2022.101194 ；https://github.com/MetaEvo/MetaBox/tree/8ddb092d9d4338d2e30792564742343544557a25 | 提供文件是MATLAB移植，非论文作者官方MATLAB代码；明确的参考commit为8ddb092d9d4338d2e30792564742343544557a25，保留BSD-3-Clause文本及适配说明 |
| fminsearchbnd | `chendashen/CLHGS/fminsearchbnd.m`，John D'Errico头部说明 | 原SHA-256：f3a9bb22b4da4144b2dcbebe4e841488349e7a9d3623a7015553ff045dd4dbcc |
| CEC2017 | 框架根目录 `cec17_func.mexw64` 及 `input_data_cec2017/` 中D30文件 | 原始二进制/数据原样保留并逐项哈希；原编译选项与C/C++源码未包含 |

所有原作者署名、出处、邮箱及已有许可文本按原文件保留。不同算法授权条件以各自来源为准；本包没有用统一许可替换第三方权利说明。这里的版本记录支持本地可核对性，不把未记录的上游版本信息写成已经验证。
